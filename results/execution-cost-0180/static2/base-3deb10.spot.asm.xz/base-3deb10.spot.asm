
/home/me/work/rnx-bench-w-0179d/probes/startup-0179/bin/p0-base-primary:     file format elf64-x86-64


Disassembly of section .text:

00000000003deb10 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame>:
  3deb10:	55                   	push   %rbp
  3deb11:	41 57                	push   %r15
  3deb13:	41 56                	push   %r14
  3deb15:	41 55                	push   %r13
  3deb17:	41 54                	push   %r12
  3deb19:	53                   	push   %rbx
  3deb1a:	48 83 ec 58          	sub    $0x58,%rsp
  3deb1e:	49 89 f6             	mov    %rsi,%r14
  3deb21:	48 89 fb             	mov    %rdi,%rbx
  3deb24:	48 8b 86 e0 00 00 00 	mov    0xe0(%rsi),%rax
  3deb2b:	48 85 c0             	test   %rax,%rax
  3deb2e:	0f 84 e0 00 00 00    	je     3dec14 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x104>
  3deb34:	48 ff c8             	dec    %rax
  3deb37:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
  3deb3e:	49 8b 8e d0 00 00 00 	mov    0xd0(%r14),%rcx
  3deb45:	48 c1 e0 05          	shl    $0x5,%rax
  3deb49:	48 8b 2c 01          	mov    (%rcx,%rax,1),%rbp
  3deb4d:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
  3deb52:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  3deb57:	4c 8b 6c 01 10       	mov    0x10(%rcx,%rax,1),%r13
  3deb5c:	0f b6 44 01 18       	movzbl 0x18(%rcx,%rax,1),%eax
  3deb61:	88 44 24 18          	mov    %al,0x18(%rsp)
  3deb65:	4d 8b a6 c0 00 00 00 	mov    0xc0(%r14),%r12
  3deb6c:	49 8b 86 c8 00 00 00 	mov    0xc8(%r14),%rax
  3deb73:	49 39 c4             	cmp    %rax,%r12
  3deb76:	0f 82 65 01 00 00    	jb     3dece1 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1d1>
  3deb7c:	0f 84 5f 01 00 00    	je     3dece1 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1d1>
  3deb82:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  3deb87:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
  3deb8c:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  3deb91:	49 8b 9e b0 00 00 00 	mov    0xb0(%r14),%rbx
  3deb98:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  3deb9d:	48 89 c5             	mov    %rax,%rbp
  3deba0:	48 c1 e5 04          	shl    $0x4,%rbp
  3deba4:	49 c1 e4 04          	shl    $0x4,%r12
  3deba8:	49 89 e7             	mov    %rsp,%r15
  3debab:	eb 10                	jmp    3debbd <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xad>
  3debad:	0f 1f 00             	nopl   (%rax)
  3debb0:	48 83 c5 10          	add    $0x10,%rbp
  3debb4:	49 39 ec             	cmp    %rbp,%r12
  3debb7:	0f 84 09 01 00 00    	je     3decc6 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1b6>
  3debbd:	0f 10 04 2b          	movups (%rbx,%rbp,1),%xmm0
  3debc1:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  3debc6:	c6 04 2b 00          	movb   $0x0,(%rbx,%rbp,1)
  3debca:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  3debcf:	0f 29 04 24          	movaps %xmm0,(%rsp)
  3debd3:	44 0f b6 2c 24       	movzbl (%rsp),%r13d
  3debd8:	c6 04 24 00          	movb   $0x0,(%rsp)
  3debdc:	4c 89 ff             	mov    %r15,%rdi
  3debdf:	e8 1c 37 0e 00       	call   4c2300 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5050925470341533934>
  3debe4:	41 80 fd 0a          	cmp    $0xa,%r13b
  3debe8:	72 c6                	jb     3debb0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xa0>
  3debea:	44 88 2c 24          	mov    %r13b,(%rsp)
  3debee:	48 8d 4c 24 21       	lea    0x21(%rsp),%rcx
  3debf3:	48 8b 01             	mov    (%rcx),%rax
  3debf6:	48 8b 49 07          	mov    0x7(%rcx),%rcx
  3debfa:	48 8d 54 24 01       	lea    0x1(%rsp),%rdx
  3debff:	48 89 4a 07          	mov    %rcx,0x7(%rdx)
  3dec03:	48 89 02             	mov    %rax,(%rdx)
  3dec06:	4c 89 f7             	mov    %r14,%rdi
  3dec09:	4c 89 fe             	mov    %r15,%rsi
  3dec0c:	ff 15 36 ef 28 00    	call   *0x28ef36(%rip)        # 66db48 <_DYNAMIC+0x2c8>
  3dec12:	eb 9c                	jmp    3debb0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xa0>
  3dec14:	4d 8b a6 c0 00 00 00 	mov    0xc0(%r14),%r12
  3dec1b:	49 8b 86 c8 00 00 00 	mov    0xc8(%r14),%rax
  3dec22:	49 39 c4             	cmp    %rax,%r12
  3dec25:	0f 82 2d 01 00 00    	jb     3ded58 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x248>
  3dec2b:	0f 84 27 01 00 00    	je     3ded58 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x248>
  3dec31:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  3dec36:	49 8b ae b0 00 00 00 	mov    0xb0(%r14),%rbp
  3dec3d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  3dec42:	48 89 c3             	mov    %rax,%rbx
  3dec45:	48 c1 e3 04          	shl    $0x4,%rbx
  3dec49:	49 c1 e4 04          	shl    $0x4,%r12
  3dec4d:	49 89 e7             	mov    %rsp,%r15
  3dec50:	eb 1b                	jmp    3dec6d <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x15d>
  3dec52:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3dec60:	48 83 c3 10          	add    $0x10,%rbx
  3dec64:	49 39 dc             	cmp    %rbx,%r12
  3dec67:	0f 84 da 00 00 00    	je     3ded47 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x237>
  3dec6d:	0f 10 44 1d 00       	movups 0x0(%rbp,%rbx,1),%xmm0
  3dec72:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  3dec77:	c6 44 1d 00 00       	movb   $0x0,0x0(%rbp,%rbx,1)
  3dec7c:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  3dec81:	0f 29 04 24          	movaps %xmm0,(%rsp)
  3dec85:	44 0f b6 2c 24       	movzbl (%rsp),%r13d
  3dec8a:	c6 04 24 00          	movb   $0x0,(%rsp)
  3dec8e:	4c 89 ff             	mov    %r15,%rdi
  3dec91:	e8 6a 36 0e 00       	call   4c2300 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5050925470341533934>
  3dec96:	41 80 fd 0a          	cmp    $0xa,%r13b
  3dec9a:	72 c4                	jb     3dec60 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x150>
  3dec9c:	44 88 2c 24          	mov    %r13b,(%rsp)
  3deca0:	48 8d 4c 24 21       	lea    0x21(%rsp),%rcx
  3deca5:	48 8b 01             	mov    (%rcx),%rax
  3deca8:	48 8b 49 07          	mov    0x7(%rcx),%rcx
  3decac:	48 8d 54 24 01       	lea    0x1(%rsp),%rdx
  3decb1:	48 89 4a 07          	mov    %rcx,0x7(%rdx)
  3decb5:	48 89 02             	mov    %rax,(%rdx)
  3decb8:	4c 89 f7             	mov    %r14,%rdi
  3decbb:	4c 89 fe             	mov    %r15,%rsi
  3decbe:	ff 15 84 ee 28 00    	call   *0x28ee84(%rip)        # 66db48 <_DYNAMIC+0x2c8>
  3decc4:	eb 9a                	jmp    3dec60 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x150>
  3decc6:	4d 8b a6 c0 00 00 00 	mov    0xc0(%r14),%r12
  3deccd:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  3decd2:	4c 8b 6c 24 48       	mov    0x48(%rsp),%r13
  3decd7:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
  3decdc:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  3dece1:	4c 39 e0             	cmp    %r12,%rax
  3dece4:	76 2b                	jbe    3ded11 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x201>
  3dece6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  3deceb:	49 89 86 c8 00 00 00 	mov    %rax,0xc8(%r14)
  3decf2:	49 89 ae e8 00 00 00 	mov    %rbp,0xe8(%r14)
  3decf9:	0f b6 44 24 18       	movzbl 0x18(%rsp),%eax
  3decfe:	24 01                	and    $0x1,%al
  3ded00:	88 03                	mov    %al,(%rbx)
  3ded02:	48 c7 43 08 01 00 00 00 	movq   $0x1,0x8(%rbx)
  3ded0a:	b8 10 00 00 00       	mov    $0x10,%eax
  3ded0f:	eb 62                	jmp    3ded73 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x263>
  3ded11:	48 89 c7             	mov    %rax,%rdi
  3ded14:	48 c1 e7 04          	shl    $0x4,%rdi
  3ded18:	49 03 be b0 00 00 00 	add    0xb0(%r14),%rdi
  3ded1f:	49 89 86 c0 00 00 00 	mov    %rax,0xc0(%r14)
  3ded26:	49 29 c4             	sub    %rax,%r12
  3ded29:	49 ff c4             	inc    %r12
  3ded2c:	0f 1f 40 00          	nopl   0x0(%rax)
  3ded30:	49 83 fc 01          	cmp    $0x1,%r12
  3ded34:	74 b0                	je     3dece6 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1d6>
  3ded36:	4c 8d 7f 10          	lea    0x10(%rdi),%r15
  3ded3a:	49 ff cc             	dec    %r12
  3ded3d:	e8 8e 1e e5 ff       	call   230bd0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.12286201476803078893>
  3ded42:	4c 89 ff             	mov    %r15,%rdi
  3ded45:	eb e9                	jmp    3ded30 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x220>
  3ded47:	4d 8b a6 c0 00 00 00 	mov    0xc0(%r14),%r12
  3ded4e:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  3ded53:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  3ded58:	4c 39 e0             	cmp    %r12,%rax
  3ded5b:	76 29                	jbe    3ded86 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x276>
  3ded5d:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
  3ded68:	c6 03 00             	movb   $0x0,(%rbx)
  3ded6b:	b8 08 00 00 00       	mov    $0x8,%eax
  3ded70:	45 31 ed             	xor    %r13d,%r13d
  3ded73:	4c 89 2c 03          	mov    %r13,(%rbx,%rax,1)
  3ded77:	48 83 c4 58          	add    $0x58,%rsp
  3ded7b:	5b                   	pop    %rbx
  3ded7c:	41 5c                	pop    %r12
  3ded7e:	41 5d                	pop    %r13
  3ded80:	41 5e                	pop    %r14
  3ded82:	41 5f                	pop    %r15
  3ded84:	5d                   	pop    %rbp
  3ded85:	c3                   	ret
  3ded86:	48 89 c7             	mov    %rax,%rdi
  3ded89:	48 c1 e7 04          	shl    $0x4,%rdi
  3ded8d:	49 03 be b0 00 00 00 	add    0xb0(%r14),%rdi
  3ded94:	49 89 86 c0 00 00 00 	mov    %rax,0xc0(%r14)
  3ded9b:	49 29 c4             	sub    %rax,%r12
  3ded9e:	49 ff c4             	inc    %r12
  3deda1:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3dedb0:	49 83 fc 01          	cmp    $0x1,%r12
  3dedb4:	74 a7                	je     3ded5d <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x24d>
  3dedb6:	4c 8d 7f 10          	lea    0x10(%rdi),%r15
  3dedba:	49 ff cc             	dec    %r12
  3dedbd:	e8 0e 1e e5 ff       	call   230bd0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.12286201476803078893>
  3dedc2:	4c 89 ff             	mov    %r15,%rdi
  3dedc5:	eb e9                	jmp    3dedb0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2a0>
  3dedc7:	48 89 c3             	mov    %rax,%rbx
  3dedca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  3dedd0:	49 ff cc             	dec    %r12
  3dedd3:	74 31                	je     3dee06 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2f6>
  3dedd5:	4d 8d 77 10          	lea    0x10(%r15),%r14
  3dedd9:	4c 89 ff             	mov    %r15,%rdi
  3deddc:	e8 ef 1d e5 ff       	call   230bd0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.12286201476803078893>
  3dede1:	4d 89 f7             	mov    %r14,%r15
  3dede4:	eb ea                	jmp    3dedd0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2c0>
  3dede6:	ff 15 fc ec 28 00    	call   *0x28ecfc(%rip)        # 66dae8 <_DYNAMIC+0x268>
  3dedec:	48 89 c3             	mov    %rax,%rbx
  3dedef:	90                   	nop
  3dedf0:	49 ff cc             	dec    %r12
  3dedf3:	74 11                	je     3dee06 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2f6>
  3dedf5:	4d 8d 77 10          	lea    0x10(%r15),%r14
  3dedf9:	4c 89 ff             	mov    %r15,%rdi
  3dedfc:	e8 cf 1d e5 ff       	call   230bd0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.12286201476803078893>
  3dee01:	4d 89 f7             	mov    %r14,%r15
  3dee04:	eb ea                	jmp    3dedf0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2e0>
  3dee06:	48 89 df             	mov    %rbx,%rdi
  3dee09:	e8 22 de 25 00       	call   63cc30 <_Unwind_Resume@plt>
  3dee0e:	ff 15 d4 ec 28 00    	call   *0x28ecd4(%rip)        # 66dae8 <_DYNAMIC+0x268>
