
/home/me/work/rnx-bench-w-0179d/probes/startup-0179/bin/p0-cand-primary:     file format elf64-x86-64


Disassembly of section .text:

00000000004e0920 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame>:
  4e0920:	55                   	push   %rbp
  4e0921:	41 57                	push   %r15
  4e0923:	41 56                	push   %r14
  4e0925:	41 55                	push   %r13
  4e0927:	41 54                	push   %r12
  4e0929:	53                   	push   %rbx
  4e092a:	48 83 ec 68          	sub    $0x68,%rsp
  4e092e:	48 89 f3             	mov    %rsi,%rbx
  4e0931:	49 89 fe             	mov    %rdi,%r14
  4e0934:	48 8b 86 e0 00 00 00 	mov    0xe0(%rsi),%rax
  4e093b:	48 85 c0             	test   %rax,%rax
  4e093e:	0f 84 fc 00 00 00    	je     4e0a40 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x120>
  4e0944:	48 ff c8             	dec    %rax
  4e0947:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
  4e094e:	48 8b 8b d0 00 00 00 	mov    0xd0(%rbx),%rcx
  4e0955:	48 c1 e0 05          	shl    $0x5,%rax
  4e0959:	48 8b 2c 01          	mov    (%rcx,%rax,1),%rbp
  4e095d:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
  4e0962:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  4e0967:	4c 8b 6c 01 10       	mov    0x10(%rcx,%rax,1),%r13
  4e096c:	0f b6 44 01 18       	movzbl 0x18(%rcx,%rax,1),%eax
  4e0971:	88 44 24 0f          	mov    %al,0xf(%rsp)
  4e0975:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  4e097c:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
  4e0983:	49 39 c4             	cmp    %rax,%r12
  4e0986:	0f 82 88 01 00 00    	jb     4e0b14 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1f4>
  4e098c:	0f 84 82 01 00 00    	je     4e0b14 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1f4>
  4e0992:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
  4e0997:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
  4e099c:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  4e09a1:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  4e09a6:	48 8b 9b b0 00 00 00 	mov    0xb0(%rbx),%rbx
  4e09ad:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  4e09b2:	48 89 c5             	mov    %rax,%rbp
  4e09b5:	48 c1 e5 04          	shl    $0x4,%rbp
  4e09b9:	49 c1 e4 04          	shl    $0x4,%r12
  4e09bd:	4c 8d 7c 24 10       	lea    0x10(%rsp),%r15
  4e09c2:	eb 19                	jmp    4e09dd <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xbd>
  4e09c4:	66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  4e09d0:	48 83 c5 10          	add    $0x10,%rbp
  4e09d4:	49 39 ec             	cmp    %rbp,%r12
  4e09d7:	0f 84 17 01 00 00    	je     4e0af4 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1d4>
  4e09dd:	0f 10 04 2b          	movups (%rbx,%rbp,1),%xmm0
  4e09e1:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4e09e6:	c6 04 2b 00          	movb   $0x0,(%rbx,%rbp,1)
  4e09ea:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  4e09ef:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  4e09f4:	44 0f b6 74 24 10    	movzbl 0x10(%rsp),%r14d
  4e09fa:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  4e09ff:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
  4e0a04:	4c 89 ff             	mov    %r15,%rdi
  4e0a07:	e8 74 8f e9 ff       	call   379980 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884>
  4e0a0c:	41 80 fe 0a          	cmp    $0xa,%r14b
  4e0a10:	72 be                	jb     4e09d0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xb0>
  4e0a12:	44 88 74 24 10       	mov    %r14b,0x10(%rsp)
  4e0a17:	48 8d 4c 24 31       	lea    0x31(%rsp),%rcx
  4e0a1c:	8b 01                	mov    (%rcx),%eax
  4e0a1e:	8b 49 03             	mov    0x3(%rcx),%ecx
  4e0a21:	48 8d 54 24 11       	lea    0x11(%rsp),%rdx
  4e0a26:	89 4a 03             	mov    %ecx,0x3(%rdx)
  4e0a29:	89 02                	mov    %eax,(%rdx)
  4e0a2b:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  4e0a30:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  4e0a35:	4c 89 fe             	mov    %r15,%rsi
  4e0a38:	ff 15 3a 2d 19 00    	call   *0x192d3a(%rip)        # 673778 <_DYNAMIC+0x2c8>
  4e0a3e:	eb 90                	jmp    4e09d0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0xb0>
  4e0a40:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  4e0a47:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
  4e0a4e:	49 39 c4             	cmp    %rax,%r12
  4e0a51:	0f 82 34 01 00 00    	jb     4e0b8b <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x26b>
  4e0a57:	0f 84 2e 01 00 00    	je     4e0b8b <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x26b>
  4e0a5d:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  4e0a62:	49 89 de             	mov    %rbx,%r14
  4e0a65:	48 8b ab b0 00 00 00 	mov    0xb0(%rbx),%rbp
  4e0a6c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  4e0a71:	48 89 c3             	mov    %rax,%rbx
  4e0a74:	48 c1 e3 04          	shl    $0x4,%rbx
  4e0a78:	49 c1 e4 04          	shl    $0x4,%r12
  4e0a7c:	eb 0f                	jmp    4e0a8d <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x16d>
  4e0a7e:	66 90                	xchg   %ax,%ax
  4e0a80:	48 83 c3 10          	add    $0x10,%rbx
  4e0a84:	49 39 dc             	cmp    %rbx,%r12
  4e0a87:	0f 84 ea 00 00 00    	je     4e0b77 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x257>
  4e0a8d:	0f 10 44 1d 00       	movups 0x0(%rbp,%rbx,1),%xmm0
  4e0a92:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4e0a97:	c6 44 1d 00 00       	movb   $0x0,0x0(%rbp,%rbx,1)
  4e0a9c:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  4e0aa1:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  4e0aa6:	44 0f b6 7c 24 10    	movzbl 0x10(%rsp),%r15d
  4e0aac:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  4e0ab1:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
  4e0ab6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  4e0abb:	e8 c0 8e e9 ff       	call   379980 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884>
  4e0ac0:	41 80 ff 0a          	cmp    $0xa,%r15b
  4e0ac4:	72 ba                	jb     4e0a80 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x160>
  4e0ac6:	44 88 7c 24 10       	mov    %r15b,0x10(%rsp)
  4e0acb:	48 8d 4c 24 31       	lea    0x31(%rsp),%rcx
  4e0ad0:	8b 01                	mov    (%rcx),%eax
  4e0ad2:	8b 49 03             	mov    0x3(%rcx),%ecx
  4e0ad5:	48 8d 54 24 11       	lea    0x11(%rsp),%rdx
  4e0ada:	89 4a 03             	mov    %ecx,0x3(%rdx)
  4e0add:	89 02                	mov    %eax,(%rdx)
  4e0adf:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  4e0ae4:	4c 89 f7             	mov    %r14,%rdi
  4e0ae7:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  4e0aec:	ff 15 86 2c 19 00    	call   *0x192c86(%rip)        # 673778 <_DYNAMIC+0x2c8>
  4e0af2:	eb 8c                	jmp    4e0a80 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x160>
  4e0af4:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  4e0af9:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  4e0b00:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  4e0b05:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
  4e0b0a:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
  4e0b0f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  4e0b14:	4c 39 e0             	cmp    %r12,%rax
  4e0b17:	76 2c                	jbe    4e0b45 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x225>
  4e0b19:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  4e0b1e:	48 89 83 c8 00 00 00 	mov    %rax,0xc8(%rbx)
  4e0b25:	48 89 ab e8 00 00 00 	mov    %rbp,0xe8(%rbx)
  4e0b2c:	0f b6 44 24 0f       	movzbl 0xf(%rsp),%eax
  4e0b31:	24 01                	and    $0x1,%al
  4e0b33:	41 88 06             	mov    %al,(%r14)
  4e0b36:	49 c7 46 08 01 00 00 00 	movq   $0x1,0x8(%r14)
  4e0b3e:	b8 10 00 00 00       	mov    $0x10,%eax
  4e0b43:	eb 62                	jmp    4e0ba7 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x287>
  4e0b45:	48 89 c7             	mov    %rax,%rdi
  4e0b48:	48 c1 e7 04          	shl    $0x4,%rdi
  4e0b4c:	48 03 bb b0 00 00 00 	add    0xb0(%rbx),%rdi
  4e0b53:	48 89 83 c0 00 00 00 	mov    %rax,0xc0(%rbx)
  4e0b5a:	49 29 c4             	sub    %rax,%r12
  4e0b5d:	49 ff c4             	inc    %r12
  4e0b60:	49 83 fc 01          	cmp    $0x1,%r12
  4e0b64:	74 b3                	je     4e0b19 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x1f9>
  4e0b66:	4c 8d 7f 10          	lea    0x10(%rdi),%r15
  4e0b6a:	49 ff cc             	dec    %r12
  4e0b6d:	e8 9e 33 d3 ff       	call   213f10 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5462397802538222765>
  4e0b72:	4c 89 ff             	mov    %r15,%rdi
  4e0b75:	eb e9                	jmp    4e0b60 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x240>
  4e0b77:	4c 89 f3             	mov    %r14,%rbx
  4e0b7a:	4d 8b a6 c0 00 00 00 	mov    0xc0(%r14),%r12
  4e0b81:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  4e0b86:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  4e0b8b:	4c 39 e0             	cmp    %r12,%rax
  4e0b8e:	76 2a                	jbe    4e0bba <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x29a>
  4e0b90:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
  4e0b9b:	41 c6 06 00          	movb   $0x0,(%r14)
  4e0b9f:	b8 08 00 00 00       	mov    $0x8,%eax
  4e0ba4:	45 31 ed             	xor    %r13d,%r13d
  4e0ba7:	4d 89 2c 06          	mov    %r13,(%r14,%rax,1)
  4e0bab:	48 83 c4 68          	add    $0x68,%rsp
  4e0baf:	5b                   	pop    %rbx
  4e0bb0:	41 5c                	pop    %r12
  4e0bb2:	41 5d                	pop    %r13
  4e0bb4:	41 5e                	pop    %r14
  4e0bb6:	41 5f                	pop    %r15
  4e0bb8:	5d                   	pop    %rbp
  4e0bb9:	c3                   	ret
  4e0bba:	48 89 c7             	mov    %rax,%rdi
  4e0bbd:	48 c1 e7 04          	shl    $0x4,%rdi
  4e0bc1:	48 03 bb b0 00 00 00 	add    0xb0(%rbx),%rdi
  4e0bc8:	48 89 83 c0 00 00 00 	mov    %rax,0xc0(%rbx)
  4e0bcf:	49 29 c4             	sub    %rax,%r12
  4e0bd2:	49 ff c4             	inc    %r12
  4e0bd5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4e0be0:	49 83 fc 01          	cmp    $0x1,%r12
  4e0be4:	74 aa                	je     4e0b90 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x270>
  4e0be6:	4c 8d 7f 10          	lea    0x10(%rdi),%r15
  4e0bea:	49 ff cc             	dec    %r12
  4e0bed:	e8 1e 33 d3 ff       	call   213f10 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5462397802538222765>
  4e0bf2:	4c 89 ff             	mov    %r15,%rdi
  4e0bf5:	eb e9                	jmp    4e0be0 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2c0>
  4e0bf7:	48 89 c3             	mov    %rax,%rbx
  4e0bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  4e0c00:	49 ff cc             	dec    %r12
  4e0c03:	74 31                	je     4e0c36 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x316>
  4e0c05:	4d 8d 77 10          	lea    0x10(%r15),%r14
  4e0c09:	4c 89 ff             	mov    %r15,%rdi
  4e0c0c:	e8 ff 32 d3 ff       	call   213f10 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5462397802538222765>
  4e0c11:	4d 89 f7             	mov    %r14,%r15
  4e0c14:	eb ea                	jmp    4e0c00 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x2e0>
  4e0c16:	ff 15 fc 2a 19 00    	call   *0x192afc(%rip)        # 673718 <_DYNAMIC+0x268>
  4e0c1c:	48 89 c3             	mov    %rax,%rbx
  4e0c1f:	90                   	nop
  4e0c20:	49 ff cc             	dec    %r12
  4e0c23:	74 11                	je     4e0c36 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x316>
  4e0c25:	4d 8d 77 10          	lea    0x10(%r15),%r14
  4e0c29:	4c 89 ff             	mov    %r15,%rdi
  4e0c2c:	e8 df 32 d3 ff       	call   213f10 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5462397802538222765>
  4e0c31:	4d 89 f7             	mov    %r14,%r15
  4e0c34:	eb ea                	jmp    4e0c20 <_RNvMs0_NtNtCs2gclYLZIe7Z_4rune7runtime2vmNtB5_2Vm14pop_call_frame+0x300>
  4e0c36:	48 89 df             	mov    %rbx,%rdi
  4e0c39:	e8 d2 1d 16 00       	call   642a10 <_Unwind_Resume@plt>
  4e0c3e:	ff 15 d4 2a 19 00    	call   *0x192ad4(%rip)        # 673718 <_DYNAMIC+0x268>
