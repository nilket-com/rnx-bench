
/home/me/work/rnx-bench-w-0179d/probes/startup-0179/bin/p0-base-primary:     file format elf64-x86-64


Disassembly of section .text:

00000000004c2300 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5050925470341533934>:
  4c2300:	41 56                	push   %r14
  4c2302:	53                   	push   %rbx
  4c2303:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  4c230a:	80 3f 0a             	cmpb   $0xa,(%rdi)
  4c230d:	0f 82 80 00 00 00    	jb     4c2393 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5050925470341533934+0x93>
  4c2313:	0f 10 07             	movups (%rdi),%xmm0
  4c2316:	0f 29 04 24          	movaps %xmm0,(%rsp)
  4c231a:	48 89 fb             	mov    %rdi,%rbx
  4c231d:	c6 07 00             	movb   $0x0,(%rdi)
  4c2320:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
  4c2329:	0f 57 c0             	xorps  %xmm0,%xmm0
  4c232c:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
  4c2331:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
  4c2336:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
  4c233b:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
  4c2340:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
  4c2345:	0f 11 84 24 80 00 00 00 	movups %xmm0,0x80(%rsp)
  4c234d:	0f 11 84 24 90 00 00 00 	movups %xmm0,0x90(%rsp)
  4c2355:	0f 11 84 24 a0 00 00 00 	movups %xmm0,0xa0(%rsp)
  4c235d:	48 c7 84 24 b0 00 00 00 00 00 00 00 	movq   $0x0,0xb0(%rsp)
  4c2369:	48 c7 44 24 20 08 00 00 00 	movq   $0x8,0x20(%rsp)
  4c2372:	48 c7 44 24 28 00 00 00 00 	movq   $0x0,0x28(%rsp)
  4c237b:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  4c2380:	48 89 e6             	mov    %rsp,%rsi
  4c2383:	ff 15 bf b7 1a 00    	call   *0x1ab7bf(%rip)        # 66db48 <_DYNAMIC+0x2c8>
  4c2389:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  4c238e:	e8 cd 11 00 00       	call   4c3560 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtNtCs2gclYLZIe7Z_4rune7runtime5value9dismantle8WorklistEBJ_.llvm.5050925470341533934>
  4c2393:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  4c239a:	5b                   	pop    %rbx
  4c239b:	41 5e                	pop    %r14
  4c239d:	c3                   	ret
  4c239e:	49 89 c6             	mov    %rax,%r14
  4c23a1:	eb 0d                	jmp    4c23b0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.5050925470341533934+0xb0>
  4c23a3:	49 89 c6             	mov    %rax,%r14
  4c23a6:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  4c23ab:	e8 b0 11 00 00       	call   4c3560 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtNtCs2gclYLZIe7Z_4rune7runtime5value9dismantle8WorklistEBJ_.llvm.5050925470341533934>
  4c23b0:	48 89 df             	mov    %rbx,%rdi
  4c23b3:	e8 d8 fe ff ff       	call   4c2290 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value4ReprEBH_.llvm.5050925470341533934>
  4c23b8:	4c 89 f7             	mov    %r14,%rdi
  4c23bb:	e8 70 a8 17 00       	call   63cc30 <_Unwind_Resume@plt>
  4c23c0:	ff 15 22 b7 1a 00    	call   *0x1ab722(%rip)        # 66dae8 <_DYNAMIC+0x268>
  4c23c6:	ff 15 1c b7 1a 00    	call   *0x1ab71c(%rip)        # 66dae8 <_DYNAMIC+0x268>
