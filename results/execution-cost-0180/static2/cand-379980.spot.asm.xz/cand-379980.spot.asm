
/home/me/work/rnx-bench-w-0179d/probes/startup-0179/bin/p0-cand-primary:     file format elf64-x86-64


Disassembly of section .text:

0000000000379980 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884>:
  379980:	55                   	push   %rbp
  379981:	41 57                	push   %r15
  379983:	41 56                	push   %r14
  379985:	41 55                	push   %r13
  379987:	41 54                	push   %r12
  379989:	53                   	push   %rbx
  37998a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  379991:	80 3f 0a             	cmpb   $0xa,(%rdi)
  379994:	0f 82 4a 04 00 00    	jb     379de4 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x464>
  37999a:	0f 10 07             	movups (%rdi),%xmm0
  37999d:	0f 29 84 24 a0 00 00 00 	movaps %xmm0,0xa0(%rsp)
  3799a5:	48 89 fb             	mov    %rdi,%rbx
  3799a8:	c6 07 00             	movb   $0x0,(%rdi)
  3799ab:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
  3799b3:	0f 57 c0             	xorps  %xmm0,%xmm0
  3799b6:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  3799bb:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  3799c0:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
  3799c5:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
  3799ca:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  3799cf:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
  3799d4:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
  3799d9:	0f 11 84 24 88 00 00 00 	movups %xmm0,0x88(%rsp)
  3799e1:	48 c7 84 24 98 00 00 00 00 00 00 00 	movq   $0x0,0x98(%rsp)
  3799ed:	48 c7 44 24 08 08 00 00 00 	movq   $0x8,0x8(%rsp)
  3799f6:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
  3799ff:	49 89 e6             	mov    %rsp,%r14
  379a02:	48 8d b4 24 a0 00 00 00 	lea    0xa0(%rsp),%rsi
  379a0a:	4c 89 f7             	mov    %r14,%rdi
  379a0d:	ff 15 65 9d 2f 00    	call   *0x2f9d65(%rip)        # 673778 <_DYNAMIC+0x2c8>
  379a13:	0f b6 4c 24 18       	movzbl 0x18(%rsp),%ecx
  379a18:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379a1c:	31 c0                	xor    %eax,%eax
  379a1e:	48 83 f9 0a          	cmp    $0xa,%rcx
  379a22:	48 0f 43 c2          	cmovae %rdx,%rax
  379a26:	48 85 c0             	test   %rax,%rax
  379a29:	74 4d                	je     379a78 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xf8>
  379a2b:	83 f8 01             	cmp    $0x1,%eax
  379a2e:	75 12                	jne    379a42 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xc2>
  379a30:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  379a36:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  379a3b:	e8 90 aa 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379a40:	eb 36                	jmp    379a78 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xf8>
  379a42:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  379a47:	49 ff 4f 08          	decq   0x8(%r15)
  379a4b:	75 2b                	jne    379a78 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xf8>
  379a4d:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379a51:	49 8b 45 40          	mov    0x40(%r13),%rax
  379a55:	48 85 c0             	test   %rax,%rax
  379a58:	74 11                	je     379a6b <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xeb>
  379a5a:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379a5e:	78 0b                	js     379a6b <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0xeb>
  379a60:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  379a66:	4c 89 ff             	mov    %r15,%rdi
  379a69:	ff d0                	call   *%rax
  379a6b:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  379a71:	4c 89 ff             	mov    %r15,%rdi
  379a74:	41 ff 55 18          	call   *0x18(%r13)
  379a78:	0f b6 4c 24 28       	movzbl 0x28(%rsp),%ecx
  379a7d:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379a81:	31 c0                	xor    %eax,%eax
  379a83:	48 83 f9 0a          	cmp    $0xa,%rcx
  379a87:	48 0f 43 c2          	cmovae %rdx,%rax
  379a8b:	48 85 c0             	test   %rax,%rax
  379a8e:	74 4d                	je     379add <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x15d>
  379a90:	83 f8 01             	cmp    $0x1,%eax
  379a93:	75 12                	jne    379aa7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x127>
  379a95:	41 bc 02 00 00 00    	mov    $0x2,%r12d
  379a9b:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  379aa0:	e8 2b aa 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379aa5:	eb 36                	jmp    379add <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x15d>
  379aa7:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  379aac:	49 ff 4f 08          	decq   0x8(%r15)
  379ab0:	75 2b                	jne    379add <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x15d>
  379ab2:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379ab6:	49 8b 45 40          	mov    0x40(%r13),%rax
  379aba:	48 85 c0             	test   %rax,%rax
  379abd:	74 11                	je     379ad0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x150>
  379abf:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379ac3:	78 0b                	js     379ad0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x150>
  379ac5:	41 bc 02 00 00 00    	mov    $0x2,%r12d
  379acb:	4c 89 ff             	mov    %r15,%rdi
  379ace:	ff d0                	call   *%rax
  379ad0:	41 bc 02 00 00 00    	mov    $0x2,%r12d
  379ad6:	4c 89 ff             	mov    %r15,%rdi
  379ad9:	41 ff 55 18          	call   *0x18(%r13)
  379add:	0f b6 4c 24 38       	movzbl 0x38(%rsp),%ecx
  379ae2:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379ae6:	31 c0                	xor    %eax,%eax
  379ae8:	48 83 f9 0a          	cmp    $0xa,%rcx
  379aec:	48 0f 43 c2          	cmovae %rdx,%rax
  379af0:	48 85 c0             	test   %rax,%rax
  379af3:	74 4d                	je     379b42 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1c2>
  379af5:	83 f8 01             	cmp    $0x1,%eax
  379af8:	75 12                	jne    379b0c <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x18c>
  379afa:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  379b00:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  379b05:	e8 c6 a9 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379b0a:	eb 36                	jmp    379b42 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1c2>
  379b0c:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  379b11:	49 ff 4f 08          	decq   0x8(%r15)
  379b15:	75 2b                	jne    379b42 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1c2>
  379b17:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379b1b:	49 8b 45 40          	mov    0x40(%r13),%rax
  379b1f:	48 85 c0             	test   %rax,%rax
  379b22:	74 11                	je     379b35 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1b5>
  379b24:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379b28:	78 0b                	js     379b35 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1b5>
  379b2a:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  379b30:	4c 89 ff             	mov    %r15,%rdi
  379b33:	ff d0                	call   *%rax
  379b35:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  379b3b:	4c 89 ff             	mov    %r15,%rdi
  379b3e:	41 ff 55 18          	call   *0x18(%r13)
  379b42:	0f b6 4c 24 48       	movzbl 0x48(%rsp),%ecx
  379b47:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379b4b:	31 c0                	xor    %eax,%eax
  379b4d:	48 83 f9 0a          	cmp    $0xa,%rcx
  379b51:	48 0f 43 c2          	cmovae %rdx,%rax
  379b55:	48 85 c0             	test   %rax,%rax
  379b58:	74 4d                	je     379ba7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x227>
  379b5a:	83 f8 01             	cmp    $0x1,%eax
  379b5d:	75 12                	jne    379b71 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x1f1>
  379b5f:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  379b65:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  379b6a:	e8 61 a9 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379b6f:	eb 36                	jmp    379ba7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x227>
  379b71:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  379b76:	49 ff 4f 08          	decq   0x8(%r15)
  379b7a:	75 2b                	jne    379ba7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x227>
  379b7c:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379b80:	49 8b 45 40          	mov    0x40(%r13),%rax
  379b84:	48 85 c0             	test   %rax,%rax
  379b87:	74 11                	je     379b9a <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x21a>
  379b89:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379b8d:	78 0b                	js     379b9a <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x21a>
  379b8f:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  379b95:	4c 89 ff             	mov    %r15,%rdi
  379b98:	ff d0                	call   *%rax
  379b9a:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  379ba0:	4c 89 ff             	mov    %r15,%rdi
  379ba3:	41 ff 55 18          	call   *0x18(%r13)
  379ba7:	0f b6 4c 24 58       	movzbl 0x58(%rsp),%ecx
  379bac:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379bb0:	31 c0                	xor    %eax,%eax
  379bb2:	48 83 f9 0a          	cmp    $0xa,%rcx
  379bb6:	48 0f 43 c2          	cmovae %rdx,%rax
  379bba:	48 85 c0             	test   %rax,%rax
  379bbd:	74 4d                	je     379c0c <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x28c>
  379bbf:	83 f8 01             	cmp    $0x1,%eax
  379bc2:	75 12                	jne    379bd6 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x256>
  379bc4:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  379bca:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  379bcf:	e8 fc a8 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379bd4:	eb 36                	jmp    379c0c <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x28c>
  379bd6:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  379bdb:	49 ff 4f 08          	decq   0x8(%r15)
  379bdf:	75 2b                	jne    379c0c <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x28c>
  379be1:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379be5:	49 8b 45 40          	mov    0x40(%r13),%rax
  379be9:	48 85 c0             	test   %rax,%rax
  379bec:	74 11                	je     379bff <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x27f>
  379bee:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379bf2:	78 0b                	js     379bff <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x27f>
  379bf4:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  379bfa:	4c 89 ff             	mov    %r15,%rdi
  379bfd:	ff d0                	call   *%rax
  379bff:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  379c05:	4c 89 ff             	mov    %r15,%rdi
  379c08:	41 ff 55 18          	call   *0x18(%r13)
  379c0c:	0f b6 4c 24 68       	movzbl 0x68(%rsp),%ecx
  379c11:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379c15:	31 c0                	xor    %eax,%eax
  379c17:	48 83 f9 0a          	cmp    $0xa,%rcx
  379c1b:	48 0f 43 c2          	cmovae %rdx,%rax
  379c1f:	48 85 c0             	test   %rax,%rax
  379c22:	74 4d                	je     379c71 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2f1>
  379c24:	83 f8 01             	cmp    $0x1,%eax
  379c27:	75 12                	jne    379c3b <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2bb>
  379c29:	41 bc 06 00 00 00    	mov    $0x6,%r12d
  379c2f:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  379c34:	e8 97 a8 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379c39:	eb 36                	jmp    379c71 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2f1>
  379c3b:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  379c40:	49 ff 4f 08          	decq   0x8(%r15)
  379c44:	75 2b                	jne    379c71 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2f1>
  379c46:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379c4a:	49 8b 45 40          	mov    0x40(%r13),%rax
  379c4e:	48 85 c0             	test   %rax,%rax
  379c51:	74 11                	je     379c64 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2e4>
  379c53:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379c57:	78 0b                	js     379c64 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x2e4>
  379c59:	41 bc 06 00 00 00    	mov    $0x6,%r12d
  379c5f:	4c 89 ff             	mov    %r15,%rdi
  379c62:	ff d0                	call   *%rax
  379c64:	41 bc 06 00 00 00    	mov    $0x6,%r12d
  379c6a:	4c 89 ff             	mov    %r15,%rdi
  379c6d:	41 ff 55 18          	call   *0x18(%r13)
  379c71:	0f b6 4c 24 78       	movzbl 0x78(%rsp),%ecx
  379c76:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379c7a:	31 c0                	xor    %eax,%eax
  379c7c:	48 83 f9 0a          	cmp    $0xa,%rcx
  379c80:	48 0f 43 c2          	cmovae %rdx,%rax
  379c84:	48 85 c0             	test   %rax,%rax
  379c87:	74 53                	je     379cdc <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x35c>
  379c89:	83 f8 01             	cmp    $0x1,%eax
  379c8c:	75 15                	jne    379ca3 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x323>
  379c8e:	41 bc 07 00 00 00    	mov    $0x7,%r12d
  379c94:	48 8b bc 24 80 00 00 00 	mov    0x80(%rsp),%rdi
  379c9c:	e8 2f a8 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379ca1:	eb 39                	jmp    379cdc <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x35c>
  379ca3:	4c 8b bc 24 80 00 00 00 	mov    0x80(%rsp),%r15
  379cab:	49 ff 4f 08          	decq   0x8(%r15)
  379caf:	75 2b                	jne    379cdc <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x35c>
  379cb1:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379cb5:	49 8b 45 40          	mov    0x40(%r13),%rax
  379cb9:	48 85 c0             	test   %rax,%rax
  379cbc:	74 11                	je     379ccf <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x34f>
  379cbe:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379cc2:	78 0b                	js     379ccf <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x34f>
  379cc4:	41 bc 07 00 00 00    	mov    $0x7,%r12d
  379cca:	4c 89 ff             	mov    %r15,%rdi
  379ccd:	ff d0                	call   *%rax
  379ccf:	41 bc 07 00 00 00    	mov    $0x7,%r12d
  379cd5:	4c 89 ff             	mov    %r15,%rdi
  379cd8:	41 ff 55 18          	call   *0x18(%r13)
  379cdc:	0f b6 8c 24 88 00 00 00 	movzbl 0x88(%rsp),%ecx
  379ce4:	48 8d 51 f7          	lea    -0x9(%rcx),%rdx
  379ce8:	31 c0                	xor    %eax,%eax
  379cea:	48 83 f9 0a          	cmp    $0xa,%rcx
  379cee:	48 0f 43 c2          	cmovae %rdx,%rax
  379cf2:	48 85 c0             	test   %rax,%rax
  379cf5:	74 53                	je     379d4a <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3ca>
  379cf7:	83 f8 01             	cmp    $0x1,%eax
  379cfa:	75 15                	jne    379d11 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x391>
  379cfc:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  379d02:	48 8b bc 24 90 00 00 00 	mov    0x90(%rsp),%rdi
  379d0a:	e8 c1 a7 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379d0f:	eb 39                	jmp    379d4a <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3ca>
  379d11:	4c 8b bc 24 90 00 00 00 	mov    0x90(%rsp),%r15
  379d19:	49 ff 4f 08          	decq   0x8(%r15)
  379d1d:	75 2b                	jne    379d4a <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3ca>
  379d1f:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  379d23:	49 8b 45 40          	mov    0x40(%r13),%rax
  379d27:	48 85 c0             	test   %rax,%rax
  379d2a:	74 11                	je     379d3d <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3bd>
  379d2c:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379d30:	78 0b                	js     379d3d <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3bd>
  379d32:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  379d38:	4c 89 ff             	mov    %r15,%rdi
  379d3b:	ff d0                	call   *%rax
  379d3d:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  379d43:	4c 89 ff             	mov    %r15,%rdi
  379d46:	41 ff 55 18          	call   *0x18(%r13)
  379d4a:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  379d4f:	4d 85 e4             	test   %r12,%r12
  379d52:	74 73                	je     379dc7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x447>
  379d54:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  379d59:	49 83 c6 10          	add    $0x10,%r14
  379d5d:	45 31 ed             	xor    %r13d,%r13d
  379d60:	eb 20                	jmp    379d82 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x402>
  379d62:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  379d70:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
  379d74:	e8 57 a7 00 00       	call   3844d0 <_RNvMs6_NtNtNtCs2gclYLZIe7Z_4rune7runtime5value12any_sequenceINtB5_15AnySequenceDataINtNtCsdBTkVrZDrQD_10rune_alloc4sync3ArcNtNtB7_4rtti4RttiENtB7_5ValueE3decBb_.llvm.16601744055780753884>
  379d79:	49 83 c6 10          	add    $0x10,%r14
  379d7d:	49 ff cc             	dec    %r12
  379d80:	74 45                	je     379dc7 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x447>
  379d82:	41 0f b6 4e f0       	movzbl -0x10(%r14),%ecx
  379d87:	48 8d 41 f7          	lea    -0x9(%rcx),%rax
  379d8b:	48 83 f9 0a          	cmp    $0xa,%rcx
  379d8f:	49 0f 42 c5          	cmovb  %r13,%rax
  379d93:	48 85 c0             	test   %rax,%rax
  379d96:	74 e1                	je     379d79 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3f9>
  379d98:	83 f8 01             	cmp    $0x1,%eax
  379d9b:	74 d3                	je     379d70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3f0>
  379d9d:	4d 8b 7e f8          	mov    -0x8(%r14),%r15
  379da1:	49 ff 4f 08          	decq   0x8(%r15)
  379da5:	75 d2                	jne    379d79 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3f9>
  379da7:	49 8b 6f 10          	mov    0x10(%r15),%rbp
  379dab:	48 8b 45 40          	mov    0x40(%rbp),%rax
  379daf:	48 85 c0             	test   %rax,%rax
  379db2:	74 0b                	je     379dbf <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x43f>
  379db4:	49 83 3f 00          	cmpq   $0x0,(%r15)
  379db8:	78 05                	js     379dbf <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x43f>
  379dba:	4c 89 ff             	mov    %r15,%rdi
  379dbd:	ff d0                	call   *%rax
  379dbf:	4c 89 ff             	mov    %r15,%rdi
  379dc2:	ff 55 18             	call   *0x18(%rbp)
  379dc5:	eb b2                	jmp    379d79 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x3f9>
  379dc7:	48 8b 34 24          	mov    (%rsp),%rsi
  379dcb:	48 85 f6             	test   %rsi,%rsi
  379dce:	74 14                	je     379de4 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x464>
  379dd0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  379dd5:	48 c1 e6 04          	shl    $0x4,%rsi
  379dd9:	ba 08 00 00 00       	mov    $0x8,%edx
  379dde:	ff 15 44 99 2f 00    	call   *0x2f9944(%rip)        # 673728 <_DYNAMIC+0x278>
  379de4:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  379deb:	5b                   	pop    %rbx
  379dec:	41 5c                	pop    %r12
  379dee:	41 5d                	pop    %r13
  379df0:	41 5e                	pop    %r14
  379df2:	41 5f                	pop    %r15
  379df4:	5d                   	pop    %rbp
  379df5:	c3                   	ret
  379df6:	49 89 c7             	mov    %rax,%r15
  379df9:	48 89 e7             	mov    %rsp,%rdi
  379dfc:	e8 7f 09 00 00       	call   37a780 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtNtCs2gclYLZIe7Z_4rune7runtime5value9dismantle8WorklistEBJ_>
  379e01:	e9 8d 00 00 00       	jmp    379e93 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x513>
  379e06:	ff 15 0c 99 2f 00    	call   *0x2f990c(%rip)        # 673718 <_DYNAMIC+0x268>
  379e0c:	49 89 c7             	mov    %rax,%r15
  379e0f:	44 89 e0             	mov    %r12d,%eax
  379e12:	c1 e0 04             	shl    $0x4,%eax
  379e15:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
  379e19:	48 83 c7 18          	add    $0x18,%rdi
  379e1d:	49 83 c4 f7          	add    $0xfffffffffffffff7,%r12
  379e21:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  379e30:	49 ff c4             	inc    %r12
  379e33:	74 0e                	je     379e43 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x4c3>
  379e35:	4c 8d 77 10          	lea    0x10(%rdi),%r14
  379e39:	e8 d2 fa ff ff       	call   379910 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value4ReprEBH_.llvm.16601744055780753884>
  379e3e:	4c 89 f7             	mov    %r14,%rdi
  379e41:	eb ed                	jmp    379e30 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x4b0>
  379e43:	48 89 e7             	mov    %rsp,%rdi
  379e46:	e8 75 e4 ff ff       	call   3782c0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtNtCs2gclYLZIe7Z_4rune7runtime5value4ReprEEB1d_>
  379e4b:	eb 46                	jmp    379e93 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x513>
  379e4d:	ff 15 c5 98 2f 00    	call   *0x2f98c5(%rip)        # 673718 <_DYNAMIC+0x268>
  379e53:	ff 15 bf 98 2f 00    	call   *0x2f98bf(%rip)        # 673718 <_DYNAMIC+0x268>
  379e59:	49 89 c7             	mov    %rax,%r15
  379e5c:	0f 1f 40 00          	nopl   0x0(%rax)
  379e60:	49 ff cc             	dec    %r12
  379e63:	74 11                	je     379e76 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x4f6>
  379e65:	4d 8d 6e 10          	lea    0x10(%r14),%r13
  379e69:	4c 89 f7             	mov    %r14,%rdi
  379e6c:	e8 ef 42 ed ff       	call   24e160 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value4ReprEBH_.llvm.1441543855779007935>
  379e71:	4d 89 ee             	mov    %r13,%r14
  379e74:	eb ea                	jmp    379e60 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x4e0>
  379e76:	48 8b 34 24          	mov    (%rsp),%rsi
  379e7a:	48 85 f6             	test   %rsi,%rsi
  379e7d:	74 14                	je     379e93 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value5ValueEBH_.llvm.16601744055780753884+0x513>
  379e7f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  379e84:	48 c1 e6 04          	shl    $0x4,%rsi
  379e88:	ba 08 00 00 00       	mov    $0x8,%edx
  379e8d:	ff 15 95 98 2f 00    	call   *0x2f9895(%rip)        # 673728 <_DYNAMIC+0x278>
  379e93:	48 89 df             	mov    %rbx,%rdi
  379e96:	e8 75 fa ff ff       	call   379910 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs2gclYLZIe7Z_4rune7runtime5value4ReprEBH_.llvm.16601744055780753884>
  379e9b:	4c 89 ff             	mov    %r15,%rdi
  379e9e:	e8 6d 8b 2c 00       	call   642a10 <_Unwind_Resume@plt>
  379ea3:	ff 15 6f 98 2f 00    	call   *0x2f986f(%rip)        # 673718 <_DYNAMIC+0x268>
  379ea9:	ff 15 69 98 2f 00    	call   *0x2f9869(%rip)        # 673718 <_DYNAMIC+0x268>
